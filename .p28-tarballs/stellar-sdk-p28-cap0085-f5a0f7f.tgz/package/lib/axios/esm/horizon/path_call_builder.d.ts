import { Asset } from "../base/index.js";
import { CallBuilder } from "./call_builder.js";
import { ServerApi } from "./server_api.js";
import type { HttpClient } from "../http-client/index.js";
/**
 * The Stellar Network allows payments to be made across assets through path payments. A path payment specifies a
 * series of assets to route a payment through, from source asset (the asset debited from the payer) to destination
 * asset (the asset credited to the payee).
 *
 * A path search is specified using:
 *
 * * The destination address
 * * The source address
 * * The asset and amount that the destination account should receive
 *
 * As part of the search, horizon will load a list of assets available to the source address and will find any
 * payment paths from those source assets to the desired destination asset. The search's amount parameter will be
 * used to determine if there a given path can satisfy a payment of the desired amount.
 *
 * Do not create this object directly, use {@link Horizon.Server.paths}.
 *
 * @see {@link https://developers.stellar.org/docs/data/horizon/api-reference/aggregations/paths | Find Payment Paths}
 *
 * @param serverUrl - Horizon server URL.
 * @param source - The sender's account ID. Any returned path must use a source that the sender can hold.
 * @param destination - The destination account ID that any returned path should use.
 * @param destinationAsset - The destination asset.
 * @param destinationAmount - The amount, denominated in the destination asset, that any returned path should be able to satisfy.
 */
export declare class PathCallBuilder extends CallBuilder<ServerApi.CollectionPage<ServerApi.PaymentPathRecord>> {
    constructor(serverUrl: URL, httpClient: HttpClient, source: string, destination: string, destinationAsset: Asset, destinationAmount: string);
}
