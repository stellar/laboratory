import { CallBuilder } from "./call_builder.js";
import { ServerApi } from "./server_api.js";
import type { HttpClient } from "../http-client/index.js";
/**
 * Creates a new {@link TransactionCallBuilder} pointed to server defined by serverUrl.
 *
 * Do not create this object directly, use {@link Horizon.Server.transactions}.
 *
 * @see {@link https://developers.stellar.org/docs/data/horizon/api-reference/resources/list-all-transactions | All Transactions}
 *
 * @param serverUrl - Horizon server URL.
 */
export declare class TransactionCallBuilder extends CallBuilder<ServerApi.CollectionPage<ServerApi.TransactionRecord>> {
    constructor(serverUrl: URL, httpClient: HttpClient);
    /**
     * The transaction details endpoint provides information on a single transaction. The transaction hash provided in the hash argument specifies which transaction to load.
     * @see {@link https://developers.stellar.org/docs/data/horizon/api-reference/resources/retrieve-a-transaction | Transaction Details}
     * @param transactionId - Transaction ID
     * @returns a CallBuilder instance
     */
    transaction(transactionId: string): CallBuilder<ServerApi.TransactionRecord>;
    /**
     * This endpoint represents all transactions that affected a given account.
     * @see {@link https://developers.stellar.org/docs/data/horizon/api-reference/resources/get-transactions-by-account-id | Transactions for Account}
     * @param accountId - For example: `GDGQVOKHW4VEJRU2TETD6DBRKEO5ERCNF353LW5WBFW3JJWQ2BRQ6KDD`
     * @returns current TransactionCallBuilder instance
     */
    forAccount(accountId: string): this;
    /**
     * This endpoint represents all transactions that reference a given claimable_balance.
     * @see {@link https://developers.stellar.org/docs/data/horizon/api-reference/resources/cb-retrieve-related-transactions | Transactions for Claimable Balance}
     * @param claimableBalanceId - Claimable Balance ID
     * @returns this TransactionCallBuilder instance
     */
    forClaimableBalance(claimableBalanceId: string): this;
    /**
     * This endpoint represents all transactions in a given ledger.
     * @see {@link https://developers.stellar.org/docs/data/horizon/api-reference/resources/retrieve-a-ledgers-transactions | Transactions for Ledger}
     * @param sequence - Ledger sequence
     * @returns current TransactionCallBuilder instance
     */
    forLedger(sequence: number | string): this;
    /**
     * This endpoint represents all transactions involving a particular liquidity pool.
     *
     * @param poolId - liquidity pool ID
     * @returns this TransactionCallBuilder instance
     */
    forLiquidityPool(poolId: string): this;
    /**
     * Adds a parameter defining whether to include failed transactions. By default only successful transactions are
     * returned.
     * @param value - Set to `true` to include failed transactions.
     * @returns current TransactionCallBuilder instance
     */
    includeFailed(value: boolean): this;
}
